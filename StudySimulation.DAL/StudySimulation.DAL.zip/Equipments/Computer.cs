﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudySimulation.DAL.Abstract;

namespace StudySimulation.DAL.Equipments
{
    class Computer : Equipment
    {
        public Computer()
        {
            name = "Computer";
        }
    }
}
