﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudySimulation.DAL.Interface;

namespace StudySimulation.DAL.Activitys
{
    class Lectures : ActivityDecorator
    {
        public Lectures(IActivity activity) : base(activity)
        {
        }

        public  override string Process()
        {
            if(Equipment.Name== "Computer")
            return "";
        }
    }
}
