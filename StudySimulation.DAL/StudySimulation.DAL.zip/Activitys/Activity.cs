﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudySimulation.DAL.Abstract;
using StudySimulation.DAL.Interface;

namespace StudySimulation.DAL.Activity
{
    public class Activity : IActivity
    {
        Equipment equipment;
        Teacher teacher;
        Room room;
        public Room Room { get => this.room; set => this.room = value; }
        public Equipment Equipment { get => this.equipment; set => this.equipment = value; }
        public Teacher Teacher { get => this.teacher; set => this.teacher = value; }

        public string Process()
        {
            return "Start of studies \r\n";
        }
    }
}
