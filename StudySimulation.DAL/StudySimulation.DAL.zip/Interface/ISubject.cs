﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudySimulation.DAL.Interface
{
    interface ISubject
    {
        List<Teacher> teachers { get; set; }
        IActivity activity { get; set; }
        void AddActivity(IActivity activity);
        void StartActivity();
        void GetResult();
    }
}
