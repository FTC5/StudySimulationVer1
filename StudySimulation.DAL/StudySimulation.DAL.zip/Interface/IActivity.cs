﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudySimulation.DAL.Abstract;

namespace StudySimulation.DAL.Interface
{
    interface IActivity
    {
        Equipment Equipment { get; set; }
        Teacher Teacher { get; set; }
        Room Room { get; set; }
        string Process(Teacher teacher,Group group,Room room,Equipment equipment=null);
    }
}
