﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudySimulation.DAL
{
    public class Student :Person
    {
        int luck;
        Random rand;
        public Student(Random rand,int minLuck=1,int maxLuck=5)
        {
            this.rand = rand;
            luck = rand.Next(minLuck, maxLuck);
        }

        public bool Study(int studentCount = 0,int boost=0)
        {
            int luckNow = this.luck;
            int randNum=0;
            luck += boost;
            luck -= studentCount / 15;
            randNum = rand.Next(0, 30);
            if (randNum + luck > 15)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
