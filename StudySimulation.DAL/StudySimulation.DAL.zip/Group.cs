﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudySimulation.DAL
{
    public class Group
    {
        List<Student> students = new List<Student>();
        string name;
        int course;

        public Group(string name, int course, List<Student> students)
        {
            Name = name;
            Course = course;
            Students = students;
        }

        public string Name { get => name; set => name = value; }
        public int Course { get => course; set => course = value; }
        internal List<Student> Students { get => students; set => students = value; }
    }
}
