﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudySimulation.DAL
{
    public class Teacher
    {
        List<Group> groups = new List<Group>();
        Dictionary<Group, Dictionary<Student, List<Work>>> result = new Dictionary<Group, Dictionary<Student, List<Work>>>();
        Dictionary<Student, List<Work>> workResults = new Dictionary<Student, List<Work>>();
        public List<Group> Groups { get => groups; set => groups = value; }

        public Dictionary<Group, Dictionary<Student, List<Work>>> Result { get => result; set => result = value; }

        
    }
}
