﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudySimulation.DAL
{
    public class Work
    {
        bool result;

        public bool Result { get => result; set => result = value; }
    }
}
