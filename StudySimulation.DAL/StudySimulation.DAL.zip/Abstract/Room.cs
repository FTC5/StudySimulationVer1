﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudySimulation.DAL.Abstract
{
    public abstract class Room
    {
        protected string name;

        public string Name { get => name; }
        protected Room()
        {
            this.name = "Room";
        }
    }
}
